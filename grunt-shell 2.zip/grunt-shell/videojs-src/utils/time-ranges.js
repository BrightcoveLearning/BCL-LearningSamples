/**
* @file time-ranges.js
*
* Should create a fake TimeRange object
* Mimics an HTML5 time range instance, which has functions that
* return the start and end times for a range
* TimeRanges are returned by the buffered() method
*
* @param  {Number} start Start time in seconds
* @param  {Number} end   End time in seconds
* @return {Object}       Fake TimeRange object
* @private
* @method createTimeRange
*/
export function createTimeRange(start, end){
  if (start === undefined && end === undefined) {
    return {
      length: 0,
      start: function() {
        throw new Error('This TimeRanges object is empty');
      },
      end: function() {
        throw new Error('This TimeRanges object is empty');
      }
    };
  }
  return {
    length: 1,
    start: function() { return start; },
    end: function() { return end; }
  };
}
