'use strict';
module.exports = function (grunt) {
  // Project configuration.
  grunt.initConfig({
    shell: {
      generateJSON: {
        command: 'jsdoc -X  -c ./conf.json ./videojs-src/component.js ./videojs-src/player.js ./videojs-src/button.js ./videojs-src/big-play-button.js > cumulative.json'
      }
    },
    concat: {
        dist: {
            src: ['var-name.txt',
                'cumulative.json',
                'semicolon.txt'
            ],
            dest: 'doc-data-full.js'
        }
    },
    uglify: {
        dist: {
            src: 'doc-data-full.js',
            dest: 'doc-data.js'
        }
    },
    remove: {
      options: {
        trace: true
      },
      fileList: ['./cumulative.json', './doc-data-full.js']
    }
 });
  // These plugins provide necessary tasks.
  grunt.loadNpmTasks('grunt-shell');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-remove');
  // Default task.
  grunt.registerTask('default', ['shell', 'concat','uglify','remove']);
}