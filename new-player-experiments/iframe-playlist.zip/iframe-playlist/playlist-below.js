videojs.plugin('pluginDev', function() {
  var player = this;
  $( "ol" ).wrap( "<div class='playlist-wrapper'></div>" );
});